export const products = [
  {
    name: 'Volume Lashes',
    price: 79,
    description: 'Some premium lashes'
  },
  {
    name: 'Simple Lashes',
    price: 49,
    description: 'Normal everyday lashes'
  }

];

export const accessories = [
  {
    name: 'Tweezers',
    price: 19,
    description: 'Tweeze your life away'
  }
];

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/